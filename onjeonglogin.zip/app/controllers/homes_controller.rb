class HomesController < ApplicationController
  def index
  end
end
