class RegisterController < ApplicationController
  def info
  end
end
